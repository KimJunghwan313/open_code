#define F_CPU 16000000UL
#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "UART0.h"
#include "UART1.h"
#include "Control.h"

#define BUFSIZE 100
#define PULSE_DUTY	100    // 출력 % 설정
#define  shift_10	10;    // 10의 자리수 이동
#define  shift_1	1;     // 1의 자리수 이동

volatile int vr_value;  // readAdc 0 값 저장
volatile int vr_100p_value;  // ADC 0~100 value 값 변환
volatile int vr_255p_value;  // ADC 0~255 value 값 변환

volatile int duty;  // out1 출력용 duty 설정
volatile int duty1;  // out2 출력용 duty 설정
volatile int num_position = 0;		// 현재 자리수 상태 확인용
volatile int now_shift = 0;  // 현재 자리수 상태
volatile int TPR_STATUS=0;  // 알람 상태 확인용
volatile unsigned int count = 0; // Timer0 count 변수
unsigned char heatcount; // 가변주기제어 출력값 저장
unsigned char mode_set=0;  // 제어모드 선택
unsigned char INPUT_SW=0;  // 제어입력 모드 선택

char LCD_print[BUFSIZE];

#define bit_set(PORTx, bitx) PORTx |= (1 << bitx)
#define bit_reset(PORTx, bitx) PORTx &= ~(1 << bitx)
#define sbi(PORTX,bitX) PORTX |= (1<<bitX)
#define cbi(PORTX,bitX) PORTX &= ~(1<<bitX)

FILE OUTPUT = FDEV_SETUP_STREAM((void *)UART0_transmit, NULL, _FDEV_SETUP_WRITE);
//FILE INPUT = FDEV_SETUP_STREAM(NULL, (void *)UART0_receive, _FDEV_SETUP_READ);


void PORT_SET()
{
	//sbi(DDRA,0); // LED1 출력
	//sbi(DDRA,1); // LED2 출력
	//sbi(DDRA,2); // LED3 출력
	cbi(DDRA,4); // 바이메탈 60도 입력 
	sbi(PORTA,4); // 바이메탈 60도 내부 풀업 저항 사용
	cbi(DDRA,5); // 바이메탈 80도 입력
	sbi(PORTA,5); // 바이메탈 80도 내부 풀업 저항 사용
	sbi(DDRA,6); // Alarm Relay1 출력
	sbi(DDRA,7); // Alarm Relay2 출력
	
	sbi(DDRB,4);  // OUT1 PORT 출력 설정
	sbi(DDRB,5);  // OUT2 PORT 출력 설정
	
	cbi(DDRC,0); // SW4 입력
	sbi(PORTC,0); // SW4 내부 풀업 저항 사용
	cbi(DDRC,1); // SW3 입력
	sbi(PORTC,1); // SW3 내부 풀업 저항 사용
	cbi(DDRC,2); // SW2 입력
	sbi(PORTC,2); // SW2 내부 풀업 저항 사용
	cbi(DDRC,3); // SW1 입력
	sbi(PORTC,3); // SW1 내부 풀업 저항 사용
	
	cbi(DDRC,4); // Slide SW1 입력
	sbi(PORTC,4); // Slide SW1 내부 풀업 저항 사용
}



void sw_control()  // 제어입력 모드 선택 SW
{
	if((PINC & 0x08) == 0x00)       // 입력 모드 설정  0 - SW / 1- VR
	{
			INPUT_SW = !INPUT_SW;   // 스위치가 눌릴시 현재 상태 반전
			_delay_ms(100);
	}
			

}

void MODE_SW()   // 출력 모드 선택 SW
{
	if((PINC & 0x10) == 0x00)
	{
		mode_set=1;   // 위상제어
	}
	else
	{
		mode_set=0;   // 가변주기제어
	}
	
}


// map 함수  (long 정수형 4바이트 , 32비트)  -> ADC 1023 -> 변환
long map(long x, long in_min, long in_max, long out_min, long out_max) {
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void INPUT_MODE()  // 제어입력 신호 VR or SW 선택 
{
	if(INPUT_SW == 1){  // VR 선택
		vr_value = readAdc(0);
		vr_100p_value = map(vr_value, 0, 1023, 0, 100);  // ADC Value 값을 0~100% 로 변환
	}
	
	else   // SW 선택
	{	
		if((PINC & 0x04) == 0x00)  // 자리수 이동
		{
			if(num_position == 0){        // 1의자리
				num_position = 1;
				now_shift = shift_1;
				_delay_ms(100);
			}
			else if(num_position == 1){  // 10의 자리
				num_position = 0;
				now_shift = shift_10;
				_delay_ms(100);
			}
		}
		
		if((PINC & 0x01) == 0x00){  // 숫자 감소
			if(vr_100p_value <= 100){ 
				if((vr_100p_value + now_shift) > 100){
					vr_100p_value = 100;
					_delay_ms(100);
				}
				else
				{
					vr_100p_value += now_shift;
					_delay_ms(100);
				}
			}
		}
		
		if((PINC & 0x02) == 0x00){  // 숫자 증가
			if(vr_100p_value > 0)
			{
				if((vr_100p_value - now_shift) < 0)
				{
					vr_100p_value = 0;
					_delay_ms(100);
				}
				else
				{
					vr_100p_value -= now_shift;
					_delay_ms(100);
				}
			}
		}
	}
}




char pulse_out(void)  // 가변주기 제어 Pulse 출력 개수설정
{
	
	char pulse=0;

	if(vr_100p_value>=3)  // 제어입력 3% 이상일때 출력 신호 ON
	{
		heatcount += vr_100p_value;  // heatcount 변수에 제어입력신호를 더한 값을 저장
		if(heatcount>=PULSE_DUTY)    // heatcount 가 100 보다 크거나 같을 시
		{
			pulse=1;                 // pulse 를 1로 변경
			heatcount-=PULSE_DUTY;   // heatcount - 100 값을 저장
		}
	}
	return pulse;                    // pulse 값을 return
}


void TPR_OUTPUT1()  // OUT1 출력 신호
{
	if(mode_set == 0){  // 가변주기제어
		_delay_us(100);  // 0.1ms 이후 출력신호 ON 
		if(pulse_out())sbi(PORTB,4);   // pulse_out의 return 값이 1일때마다 1Cycle 씩 출력한다.
		_delay_ms(8);  // 출력신호를 8ms(반주기) 만큼 유지
		cbi(PORTB,4);  // 출력신호 Off
	}
	
	else   // 위상제어
	{
		if( vr_100p_value >= 3 ){ //제어입력 3% 이상일때 출력신호 ON
			_delay_us(100); // 0.1ms 이후 출력신호 ON
			sbi(PORTB,4);
			for(duty=0; duty < (100- vr_100p_value); duty++){  // 입력신호 만큼 1Cycle을 제어
				_delay_us(80);  // 100%일때 80us * 100  = 8ms(반주기)
			}
			cbi(PORTB,4);  // 출력신호 Off
		}
		else // 제어입력 신호가 3% 이하일때 출력 동작안함.
		{
			cbi(PORTB,4);
		}
	}
	
}

void TPR_OUTPUT2()  // OUT2 출력 신호
{
	if(mode_set ==0){   // 가변주기제어
	
		_delay_us(100);  // 0.1ms 이후 출력신호 ON 
		if(pulse_out())sbi(PORTB,5);    // pulse_out의 return 값이 1일때마다 1Cycle 씩 출력한다.
		_delay_ms(7);  // 출력신호를 8ms(반주기) 만큼 유지
		cbi(PORTB,5);  // 출력신호 Off
	}
	
	else              // 위상제어
	{
		if( vr_100p_value >= 3 ){ //제어입력 3% 이상일때 출력신호 ON
			_delay_us(100); // 0.1ms 이후 출력신호 ON
			sbi(PORTB,5);
			for(duty1=0; duty1 < (100 - vr_100p_value); duty1++){  // 입력신호 만큼 1Cycle을 제어
			
				_delay_us(80);  // 100%일때 80us * 100  = 8ms(반주기)
			}
			cbi(PORTB,5);  // 출력신호 Off
		}
		else // 제어입력 신호가 3% 이하일때 출력 동작안함.
		{
			cbi(PORTB,5);
		}
		
	}
}



ISR(INT0_vect) // ZERO1 External Interrupt
{
	TPR_OUTPUT1();  // 외부 인터럽트0 -> TPR_OUTPUT1 함수 동작
}
	

ISR(INT1_vect) // ZERO2 External Interrupt
{
	TPR_OUTPUT2();	// 외부 인터럽트1 -> TPR_OUTPUT2 함수 동작
}

void zero_init()
{
	cli();
	
	EICRA |= (1<<ISC00) | (1<<ISC01) | (1<<ISC10) | (1<<ISC11);
	EIMSK |= (1<<INT0) | (1<<INT1);
	
	sei();
}



void Alarm_state()  // 알람 검출 (현재는 바이메탈 60/80 접점 신호만 검출)
{
	
	//알람1
	if(((PINA & 0x10) == 0x10) && ((PINA & 0x20) == 0x00))  // 바이메탈 60℃ 시
	{
		sbi(PORTA,6);
		TPR_STATUS=1;
		//Alarm1 ON!!
	}
	
	//알람2
	else if ( (((PINA & 0x10) == 0x00) && ((PINA & 0x20) ==0x20)) || (((PINA & 0x10) == 0x10) && ((PINA & 0x20) ==0x20)) ) // 바이메탈 80℃ 시
	{
		sbi(PORTA,7);
		//Alarm2 ON!!
		cbi(PORTA,6);
		//Alarm1 OFF!!
		TPR_STATUS=2;
	}
	else  // 노말 상태 (알람 X)
	{
		cbi(PORTA,6);
		cbi(PORTA,7);
		TPR_STATUS=0;
	}
}



/************************************************
				LCD 문자 출력
***********************************************/



void LCD_STATUS()
{
	//TPR_STATUS 0: 정상 / 1: 알람1 / 2: 알람2     // mode_set 0 : 가변주기제어 / 1: 위상제어  //  input_set  0: sw / 1: vr
		if((TPR_STATUS==0)&&(mode_set==0)&&(INPUT_SW==1))   // 정상 / 가변주기 / vr
		{
			sprintf(LCD_print,"VALI CON : %d%% A\r", vr_100p_value);	
		}
		
		if((TPR_STATUS==1)&&(mode_set==0)&&(INPUT_SW==1))   //알람1 / 가변주기 / vr
		{
			sprintf(LCD_print,"VALI CON : %d%% B\r", vr_100p_value);
		}
		
		if((TPR_STATUS==2)&&(mode_set==0)&&(INPUT_SW==1))   //알람2 / 가변주기 / vr
		{
			sprintf(LCD_print,"VALI CON : %d%% C\r", vr_100p_value);
		}
		if((TPR_STATUS==0)&&(mode_set==0)&&(INPUT_SW==0))   //정상/ 가변주기 / 스위치
		{
			sprintf(LCD_print,"VALI CON : %d%% D\r", vr_100p_value);
		}
		if((TPR_STATUS==1)&&(mode_set==0)&&(INPUT_SW==0))   //알람1 / 가변주기 / 스위치
		{
			sprintf(LCD_print,"VALI CON : %d%% E\r", vr_100p_value);
		}
		if((TPR_STATUS==2)&&(mode_set==0)&&(INPUT_SW==0))   //알람2 / 가변주기 / 스위치
		{
			sprintf(LCD_print,"VALI CON : %d%% F\r", vr_100p_value);
		}
		
		
		if((TPR_STATUS==0)&&(mode_set==1)&&(INPUT_SW==1))   // 정상 /위상제어 / vr
		{
			sprintf(LCD_print,"PHAS CON : %d%% A\r", vr_100p_value);
		}
		
		if((TPR_STATUS==1)&&(mode_set==1)&&(INPUT_SW==1))   //알람1 / 위상제어 / vr
		{
			sprintf(LCD_print,"PHAS CON : %d%% B\r", vr_100p_value);
		}
		
		if((TPR_STATUS==2)&&(mode_set==1)&&(INPUT_SW==1))   //알람2 / 위상젱어 / vr
		{
			sprintf(LCD_print,"PHAS CON : %d%% C\r", vr_100p_value);
		}
		if((TPR_STATUS==0)&&(mode_set==1)&&(INPUT_SW==0))   //정상/ 위상제어 / 스위치
		{
			sprintf(LCD_print,"PHAS CON : %d%% D\r", vr_100p_value);
		}
		if((TPR_STATUS==1)&&(mode_set==1)&&(INPUT_SW==0))   //알람1 / 위상제어 / 스위치
		{
			sprintf(LCD_print,"PHAS CON : %d%% E\r", vr_100p_value);
		}
		if((TPR_STATUS==2)&&(mode_set==1)&&(INPUT_SW==0))   //알람2 / 위상제어 / 스위치
		{
			sprintf(LCD_print,"PHAS CON : %d%% F\r", vr_100p_value);
		}
		
		UART1_print_string(LCD_print);
		
}


/************************************************
				Timer0
***********************************************/


ISR(TIMER0_OVF_vect)  //15.93us 타이머
{
	count++;  // 인터럽트 발생 횟수
	if(count>=32)  // 약 79.5us  -> 100회시 약 8ms
	{
		
		count = 0;
	}
	
}


void TIMER_init()
{
	TCCR0 |= (1 << CS02) | (1 << CS01) | (1 << CS00);  // 8비트 타이머0 분주 1024  (255*1024)/16M = 16.32ms
	//TCCR0 |= (1<<CS00); // 255/16M = 15.93us
	//TCCR1B |= (1 << CS12); // 16비트 타이머1 분주 1024   ((65536 / 16M) = 4.096ms
	TIMSK |= (1 << TOIE0) | (1 << TOIE1);
	
	sei();
}


int main(void){
	
	
	/*----------------------------------------------------
			    file input, output, UART
	-----------------------------------------------------*/
	UART0_init();
	UART1_init();
	stdout = &OUTPUT;
	//stdin  = &INPUT;
	/*----------------------------------------------------
				ADC init enable
	-----------------------------------------------------*/
	adcInit();
	/*----------------------------------------------------
				Timer init enable
	-----------------------------------------------------*/
	//TIMER_init();
	/*----------------------------------------------------
				External Interrupt enable
	-----------------------------------------------------*/
	zero_init();
	/*----------------------------------------------------
				Port init enable
	-----------------------------------------------------*/
	PORT_SET();
	sei();
	
	
	while(1){
		pulse_out();
		sw_control();
		Alarm_state();
		INPUT_MODE();
		MODE_SW();
		LCD_STATUS();
	}
}