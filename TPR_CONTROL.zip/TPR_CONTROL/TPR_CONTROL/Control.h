﻿#ifndef CONTROL_H_
#define CONTROL_H_

void adcInit(void);
uint16_t readAdc(uint8_t channel);

#endif