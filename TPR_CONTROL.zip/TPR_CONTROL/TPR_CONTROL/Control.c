﻿#define F_CPU 16000000UL
#include <avr/io.h>


/*----------------------------------------------------
ADC init, channel
-----------------------------------------------------*/


void adcInit(void)  //ADC 초기화 함수
{
	ADCSRA |= ((1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)); //16Mhz/128 = 125Khz
	ADMUX |= (1<<REFS0);       //AVCC(5V)
	ADCSRA |= (1<<ADEN);       //ADC 인에이블
}
//0~65535
uint16_t readAdc(uint8_t channel)
{

	ADMUX |= 0x00;
	ADMUX |= channel;		  // ADC 핀 설정

	ADCSRA |= (1<<ADSC);      //변환 시작
	while(ADCSRA&(1<<ADSC));  //변환 완료 대기

	return ADCW;              //ADC값 반환
}
