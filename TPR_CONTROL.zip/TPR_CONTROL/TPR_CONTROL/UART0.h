﻿#ifndef UART0_H_
#define UART0_H_

void UART0_init(void);	//uart 통신 설정 및 초기화
void UART0_transmit(char data);		//데이터 1개 송신 함수
unsigned char UART0_receive(void);	// 데이터 1개 수신 함수
void UART0_print_string(char *str);		//문자열 송신
void UART0_print_1_byte_number(uint8_t n);	//UART 통신으로 1바티으 크기 정수 출력

#endif 