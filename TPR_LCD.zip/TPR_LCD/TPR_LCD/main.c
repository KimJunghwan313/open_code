#define F_CPU 16000000UL
#include <avr/io.h> 
#include <stdio.h>
#include <string.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "UART1.h"
#include "LCD.h"

uint8_t MODE = 4;   // LCD MODE 선택을 위한 변수

FILE OUTPUT = FDEV_SETUP_STREAM((void *)UART0_transmit, NULL, _FDEV_SETUP_WRITE);
//FILE INPUT = FDEV_SETUP_STREAM(NULL, (void *)UART1_receive, _FDEV_SETUP_READ);

extern volatile int rx1flag;
extern char rx1data[BUFSIZE];
extern volatile int LCD_size;   // LCD 크기 확인용!!!!!
extern volatile int lcd_end;

//volatile char LCD_print[BUFSIZE];

void LCD_START()  // LCD 초기 화면
{
	LCD_INIT();  // LCD 초기화
	LCD_GOTO_XY(0,1);
	LCD_WRITE_STRING("TEST_TPR");
	LCD_GOTO_XY(1,1);
	LCD_WRITE_STRING("REV.0");
	_delay_ms(1000);  // 1초 대기
	LCD_CLEAR();
}


volatile unsigned int count = 0; // 비교용 변수
volatile int rx_size = 0;
volatile int rx_prev_size = 0;
char arr_test_1[BUFSIZE];
char arr_test_2[BUFSIZE];
ISR(TIMER0_OVF_vect)  //16.38ms 타이머
{
	count++;  // 인터럽트 발생 횟수
	if(count>=32)  // 약 0.5초 초마다 동작 
	{
			if(lcd_end == 'A' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("VR MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("Normal.");
			}
			
			if(lcd_end == 'B' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("VR MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("ALRAM 1");

			}
			if(lcd_end == 'C' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("VR MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("ALRAM 2");

			}
			
			if(lcd_end == 'D' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("SW MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("Normal.");

			}
			
			if(lcd_end == 'E' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("SW MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("ALRAM 1");

			}
			if(lcd_end == 'F' )
			{
				LCD_GOTO_XY(0,1);
				LCD_WRITE_STRING(rx1data);
				LCD_GOTO_XY(1,1);
				LCD_WRITE_STRING("SW MODE/");
				LCD_GOTO_XY(1,9);
				LCD_WRITE_STRING("ALRAM 2");

			}
		LCD_CLEAR();
		count = 0;
	}
	
}


void view_lcd()  // LCD 화면 출력
{
	if(lcd_end == 'A' ) 
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("VR MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("Normal.");
	}
	
	if(lcd_end == 'B' )
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("VR MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("ALRAM 1");

	}
	if(lcd_end == 'C' )
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("VR MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("ALRAM 2");

	}
	
	if(lcd_end == 'D' )
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("SW MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("Normal.");

	}
	
	if(lcd_end == 'E' )
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("SW MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("ALRAM 1");

	}
	if(lcd_end == 'F' )
	{
		LCD_GOTO_XY(0,1);
		LCD_WRITE_STRING(rx1data);
		LCD_GOTO_XY(1,1);
		LCD_WRITE_STRING("SW MODE/");
		LCD_GOTO_XY(1,9);
		LCD_WRITE_STRING("ALRAM 2");

	}
	
}



void TIMER_init0()
{
	TCCR0 |= (1 << CS02) | (1 << CS01) | (1 << CS00);  // 분주 1024    256*1024 / 16M    =  16.38ms
	TIMSK |= (1 << TOIE0);
	
	sei();
}


int main(void)
{
	stdout = &OUTPUT;
	LCD_START();
	UART1_init();
	UART0_init();
	sei();
	printf("UAR1 start\r\n");
	while (1)
    {
		view_lcd();
    }
}

