﻿#define F_CPU 16000000UL
#include <avr/io.h>
#include "LCD.h"

void LCD_PULSE_ENABLE()  // LCD Enable 사용 함수
{
	PORT_CONTROL |= (1<<E_PIN); // Enable 핀 HIGH 설정
	_delay_ms(1);
	PORT_CONTROL &= ~(1<<E_PIN); // Enable 핀 LOW 설정
	_delay_ms(1);
}

void LCD_WRITE_DATA(uint8_t data) // LCD WRITE용 함수
{
	PORT_CONTROL |= (1<<RS_PIN); // RS_PIN HIGH 설정
	if(MODE == 8)  // 8비트 전송 방식 LCD 설정
	{
		PORT_DATA = data;
		LCD_PULSE_ENABLE();
	}
	else // 상위 4비트 전송 방식 LCD 설정
	{
		PORT_DATA = data & 0xf0;  // 상위 4비트 처리
		LCD_PULSE_ENABLE();
		PORT_DATA = (data << 4) & 0xf0;  // 하위 4비트 처리
		LCD_PULSE_ENABLE();
	}
	_delay_ms(2);
}

void LCD_WRITE_COMMAND(uint8_t command)  // LCD WRITE 명령 함수
{
	PORT_CONTROL &= ~(1 << RS_PIN); // 명령어 실행할 때는 RS핀이 LOW
	
	if(MODE == 8) //8비트 전송 방식 LCD 설정
	{
		PORT_DATA = command;  // 데이터 핀에 명령어 전달
		LCD_PULSE_ENABLE();
		
	}
	else // 4비트전송 방식 LCD 설정
	{
		PORT_DATA = command & 0xf0;  // 상위 4비트 처리
		LCD_PULSE_ENABLE();
		
		PORT_DATA = (command<<4) & 0xf0;  // 하위 4비트 처리
		LCD_PULSE_ENABLE();
	}
	_delay_ms(2);
}


void LCD_CLEAR() //LCD CLEAR 함수
{
	LCD_WRITE_COMMAND(COMMAND_CLEAR_DISPLAY);  // LCD CLEAR 하기 위한 명령
	_delay_ms(1);
}

void LCD_INIT() // LCD 초기화 함수
{
	_delay_ms(50);
	
	if(MODE == 8) //8비트 방식 LCD 설정
	{
		DDR_DATA = 0xff;  // 모든 포트 출력 설정
	}
	else  // 4비트 방식 CLD 설정
	{
		DDR_DATA |= 0xf0;  // 상위 4비트 포트만 출력 설정
	}
	
	PORT_DATA = 0x00; // 초기값 설정
	DDR_CONTROL |= (1<<RS_PIN) | (1<<RW_PIN) | (1<<E_PIN);  //RS핀, RW핀, E핀 HIGH 설정
	PORT_CONTROL &= ~(1<< RW_PIN); // WRITE 하기 위한 RW핀 설정
	
	if(MODE == 8) //8비트 방식 LCD 설정
	{
		LCD_WRITE_COMMAND(COMMAND_8_BIT_MODE);  // 8비트 모드 설정
	}
	else
	{
		LCD_WRITE_COMMAND(0x02); // 4비트 모드 추가 명령
		LCD_WRITE_COMMAND(COMMAND_4_BIT_MODE); // 4비트 모드 설정
	}
	uint8_t command = 0x08 | (1<<COMMNAND_DISPLAY_ON_OFF_BIT); // 화면 ON, 커서 OFF, 깜빡임 OFF
	LCD_WRITE_COMMAND(command);
	LCD_CLEAR(); // 화면 지우기
	LCD_WRITE_COMMAND(0x06); // 출력 후 커서 오른쪽으로 옮기기
}

void LCD_WRITE_STRING(char *string)
{
	uint8_t i; // 반복 변수
	for(i=0; string[i]; i++)  // 종료 문자까지 반복
	{
		LCD_WRITE_DATA(string[i]);  // 문자 단위 출력
	}
}

void LCD_GOTO_XY(uint8_t row, uint8_t col)
{
	col %= 16; // 0~15까지 열 설정
	row %=2; // 0~1까지 행 설정
	
	uint8_t address = (0x40 * row) + col;  // 첫번째 라인 주소 : 0x00, 두번째 라인 주소 : 0x40
	uint8_t command = 0x80 + address;
	
	LCD_WRITE_COMMAND(command);
}