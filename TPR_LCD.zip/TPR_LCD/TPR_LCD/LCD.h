﻿#ifndef LCD_H_
#define LCD_H_


#include <avr/io.h>
#include <util/delay.h>

#define PORT_DATA PORTA // 데이터 핀 연결 포트
#define PORT_CONTROL PORTC // 제어 핀 연결 포트
#define DDR_DATA DDRA  // 데이터 핀 데이터 방향 설정
#define DDR_CONTROL DDRC // 제어핀 데이터 방향 설정

#define RS_PIN 0  // RS 제어핀 번호 설정
#define RW_PIN 1  // RW 제어핀 번호 설정
#define E_PIN 2  // E 제어핀 번호 설정

#define COMMAND_CLEAR_DISPLAY 0x01 // CLEAR DISPLAY 레지스터 설정
#define COMMAND_8_BIT_MODE 0x38  //8비트, 2라인 5x8 폰트
#define COMMAND_4_BIT_MODE 0x28 // 4비트, 2라인 5x8 폰트

#define COMMNAND_DISPLAY_ON_OFF_BIT 2  // 디스플레이 ON OFF 비트 설정
#define COMMNAND_CURSOR_ON_OFF_BIT 1  // 커서 ON OFF 비트 설정
#define COMMNAND_BLINK_ON_OFF_BIT 0  // 빈칸 ON OFF 비트 설정

extern uint8_t MODE; // 4비트, 8비트 방식 지정용 변수 선언

void LCD_PULSE_ENABLE(); // LCD Enable 사용 함수
void LCD_WRITE_DATA(uint8_t data); // LCD WRITE용 함수
void LCD_WRITE_COMMAND(uint8_t command);  // LCD WRITE 명령 함수
void LCD_CLEAR(); //LCD CLEAR 함수
void LCD_INIT(); // LCD 초기화 함수
void LCD_WRITE_STRING(char *string); // 문자열 출력함수 (매개변수)로 받음
void LCD_GOTO_XY(uint8_t row, uint8_t col); // LCD 커서 이동 좌표 함수

#endif